let input = "";
const passwordInput = document.getElementById("input");

function pressKey(key) {
  if (input.length < 10) {
    input += key;
    passwordInput.value = "*".repeat(input.length);
  }
}

function checkCode() {
  if (input === "140425") {
    document.getElementById("loginPanel").style.display = "none";
    document.getElementById("loveCard").style.display = "block";
    startCounter();
  } else {
    alert("Código incorrecto 😢");
  }
  input = "";
  passwordInput.value = "";
}

function startCounter() {
  const startDate = new Date("2025-04-14T00:00:00");

  setInterval(() => {
    const now = new Date();
    let diff = now - startDate;

    const years = now.getFullYear() - startDate.getFullYear();
    const months = now.getMonth() - startDate.getMonth() + (years * 12);
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    document.getElementById("years").textContent = Math.floor(months / 12);
    document.getElementById("months").textContent = months % 12;
    document.getElementById("days").textContent = String(days).padStart(2, '0');
    document.getElementById("hours").textContent = String(hours).padStart(2, '0');
    document.getElementById("minutes").textContent = String(minutes).padStart(2, '0');
    document.getElementById("seconds").textContent = String(seconds).padStart(2, '0');
  }, 1000);
}

// Corazones cayendo
function crearCorazones() {
  const heart = document.createElement('div');
  heart.className = 'heart';
  heart.textContent = '💖';
  heart.style.left = Math.random() * 100 + "vw";
  heart.style.animationDuration = (Math.random() * 2 + 3) + "s";
  document.body.appendChild(heart);

  setTimeout(() => {
    heart.remove();
  }, 5000);
}

setInterval(crearCorazones, 300);

// Mensaje animado
function mostrarMensaje() {
  const container = document.getElementById("mensajeContainer");
  const texto = document.getElementById("mensajeTexto");
  const mensaje = "Desde el 14 de abril, cada día contigo ha sido un regalo. Gracias por estar aquí, por cada risa, cada abrazo y cada momento compartido. Te amo, Nahomi 💖";

  container.classList.add("expandido");
  texto.textContent = "";
  let i = 0;

  const escribir = () => {
    if (i < mensaje.length) {
      texto.textContent += mensaje.charAt(i);
      i++;
      setTimeout(escribir, 50);
    }
  };

  escribir();
}

function volver() {
  document.getElementById("loginPanel").style.display = "flex";
  document.getElementById("loveCard").style.display = "none";
  document.getElementById("mensajeContainer").classList.remove("expandido");
  document.getElementById("mensajeTexto").textContent = "";
}
